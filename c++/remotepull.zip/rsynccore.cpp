#include "rsynccore.h"
#include <QRegularExpression>

RsyncCore::RsyncCore(QObject *parent) : QObject(parent), process(new QProcess(this)) {
    connect(process, &QProcess::readyReadStandardOutput, this, &RsyncCore::readOutput);
    connect(process, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished), this, &RsyncCore::finished);
}

void RsyncCore::startTransfer(const QStringList &args) {
    process->setProcessChannelMode(QProcess::MergedChannels);
    process->start("sshpass", args);
}

void RsyncCore::readOutput() {
    QByteArray data = process->readAllStandardOutput();
    QString output = QString::fromUtf8(data);
    QStringList lines = output.split(QRegularExpression("[\r\n]"), Qt::SkipEmptyParts);

    for (const QString &line : lines) {
        emit rawOutputReceived(line); // Stuur rauwe tekst naar de popup
        
        if (line.contains("%")) {
            QRegularExpression re("(\\d+)%.*?(\\d+\\.\\d+\\w+/s).*?(\\d+:\\d+:\\d+)");
            auto match = re.match(line);
            if (match.hasMatch()) {
                emit progressUpdated(match.captured(1).toInt(), match.captured(2), match.captured(3));
            }
        }
    }
}

void RsyncCore::stop() {
    if (process->state() == QProcess::Running) process->terminate();
}
