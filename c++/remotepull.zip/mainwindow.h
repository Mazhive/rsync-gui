#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QWidget>
#include <QLineEdit>
#include <QCheckBox>
#include <QTabWidget>
#include <QMenuBar>
#include <QAction>
#include "rsynccore.h"
#include "progressdialog.h"

class MainWindow : public QWidget {
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    void setExtraParams(QString p);

private slots:
    void onPlayClicked();
    void showRsyncCommand();
    void browseSource();
    void browseDestination();
    void handleFinished(int code);
#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QWidget>
#include <QLineEdit>
#include <QCheckBox>
#include <QTabWidget>
#include <QMenuBar>
#include <QAction>
#include "rsynccore.h"
#include "progressdialog.h"

class MainWindow : public QWidget {
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    
    // Functie om parameters vanuit de terminal (ArgumentHandler) te ontvangen
    void setExtraParams(QString p);

private slots:
    // Acties voor de knoppen en menu's
    void onPlayClicked();
    void showRsyncCommand();
    void browseSource();
    void browseDestination();
    void handleFinished(int code);

private:
    // Hulpmethode voor menu-opbouw
    void createMenus();

    // Input velden: Credentials en Paden
    QLineEdit *uIn;       // Gebruiker
    QLineEdit *hIn;       // Server IP / Host
    QLineEdit *pIn;       // Wachtwoord
    QLineEdit *lSrcIn;    // Lokaal Bron Pad (Source)
    QLineEdit *rPathIn;   // Remote Bron Pad (Source)
    QLineEdit *lPathIn;   // Bestemming Pad (Destination)
    QLineEdit *extraIn;   // Handmatige parameters veld

    // Rsync Opties (Vinkjes)
    QCheckBox *chkTime;           // -t (Preserve time)
    QCheckBox *chkOwner;          // -o (Preserve owner)
    QCheckBox *chkPerms;          // -p (Preserve permissions)
    QCheckBox *chkGroup;          // -g (Preserve group)
    QCheckBox *chkDelete;         // --delete (Delete on destination)
    QCheckBox *chkVerbose;        // -v (Verbose)
    QCheckBox *chkIgnoreExist;    // --ignore-existing
    QCheckBox *chkSkipNewer;      // -u (Update/Skip newer)
    QCheckBox *chkNoFilesystem;   // -x (Do not leave filesystem)
    QCheckBox *chkProgress;       // --progress (Show transfer progress)
    QCheckBox *chkSizeOnly;       // --size-only
    QCheckBox *chkDryRun;         // --dry-run (Simulation)

    // Logische modules
    RsyncCore *core;      // De Rsync engine
    ProgressDialog *diag; // De popup voor voortgang
};

#endif // MAINWINDOW_H
